package com.example.kuis_e_123190057

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
