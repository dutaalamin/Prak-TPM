package com.example.responsi_tpm_genshin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
