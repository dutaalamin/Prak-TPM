class CharaItem {
  CharaItem({this.name});
  String name;
}
