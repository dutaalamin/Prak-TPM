package com.example.kuis_123190085

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
